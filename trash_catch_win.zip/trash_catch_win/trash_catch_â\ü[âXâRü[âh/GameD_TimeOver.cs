using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GameD_TimeOver : MonoBehaviour
{
    private bool timeOver;
    [SerializeField] private GameObject TimeOverPanel;
    [SerializeField] private TextMeshProUGUI scoreText;
    [SerializeField] private TextMeshProUGUI resultScore;

    // Start is called before the first frame update
    void Start()
    {
        TimeOverPanel.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        timeOver = GetComponent<GameD_timer>().timeOver; //GameD_timer���^�C���I�[�o�[����̎擾
        if (timeOver)
        {
            //�^�C���I�[�o�[���Ƀ��U���g�̕\��
            TimeOverPanel.SetActive(true);
            resultScore.text = "Score: " + scoreText.text;
        }
    }
}
