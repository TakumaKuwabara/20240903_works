using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemController : MonoBehaviour
{
    Rigidbody rb;
    private int yforcemin = 23;
    private int yforcemax = 33;
    private int zforcemin = 120;
    private int zforcemax = 180;

    public bool onRoom;

    [SerializeField] LayerMask Room;
    [SerializeField] GameObject Shadow;
    private float shadowHeight = 0.1f;

    [SerializeField] private float shootPower = 1;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.AddForce(new Vector3(0, Random.Range(yforcemin, yforcemax), Random.Range(zforcemin, zforcemax) * -1) * shootPower); //�ˏo
    }

    void FixedUpdate()
    {
        if (onRoom)
        {
            Shadow.GetComponent<MeshRenderer>().enabled = false;
            if (-7.0 < transform.position.x || transform.position.x < -11.7 || 2.4 < transform.position.z || transform.position.z < -1.2 || transform.position.y < -1.0)
            {
                //�ڒn��A��ʊO�ɏo�����A����
                Destroy(gameObject);
            }
        }

        //�e�̑���
        Ray ray = new Ray(transform.position, -Vector3.up);
        if (Physics.Raycast(ray, out RaycastHit hit, 10, Room) && !onRoom)
        {
            Vector3 shadowPosition = hit.point + transform.up * shadowHeight; //�S�~�̐^�����e�̈ʒu�ƂȂ�悤�ɂ���
            Quaternion shadowRotation = Quaternion.FromToRotation(Vector3.up, hit.normal); //��m���ƕ��s�ɂȂ�悤�Ɋp�x��ݒ�
            
            Shadow.transform.position = shadowPosition;
            Shadow.transform.rotation = shadowRotation;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        int layer = collision.gameObject.layer;
        string layerName = LayerMask.LayerToName(layer);
        if(!onRoom && layerName == "Room") onRoom = true; //�ڒn����
    }
}
