using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;

public class WasteBin_Move : MonoBehaviour
{
    [SerializeField] private GameD_timer gdt;
    public LayerMask layer_room;
    [SerializeField] private float moveSpeed;
    [SerializeField] private float xmin;
    [SerializeField] private float xmax;
    [SerializeField] private float zmin;
    [SerializeField] private float zmax;

    // Start is called before the first frame update
    void Start()
    {
        transform.position = new Vector3(-9.2f, 0f, 0.5f); //�����ʒu
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!gdt.countDownOver) return;
        if (gdt.timeOver) return;

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if(Physics.Raycast(ray, out RaycastHit hit, 50, layer_room))
        {
            //�}�E�X�J�[�\���̈ʒu�ɍ��킹�Ĉړ�
            Vector3 targetPosition = Vector3.Scale(hit.point, new Vector3(1, 0, 1));
            transform.position = Vector3.Lerp(transform.position, targetPosition, moveSpeed * Time.deltaTime);
        }

        //�ړ��ł���͈͂̐���
        Vector3 pos = transform.position;
        pos.x = Mathf.Clamp(pos.x, xmin, xmax);
        pos.z = Mathf.Clamp(pos.z, zmin, zmax);
        transform.position = pos;
    }
}
