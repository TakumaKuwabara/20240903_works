using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemGenerator_Special : MonoBehaviour
{
    [SerializeField] private GameObject[] Items;
    private GameObject shooted;
    [SerializeField] private float xmin, xmax, ymin, ymax;
    [SerializeField] private Slider SpecialGauge;

    public float specialGauge_Value;
    private float specialGauge_Max;
    [SerializeField] private float gain_Ratio;

    [SerializeField] private AudioSource aud;
    [SerializeField] private AudioClip shootSE;
    private void Shoot()
    {
        int randomnum = Random.Range(0, Items.Length);

        shooted = Items[randomnum];

        Vector3 instantiatepos = new Vector3(Random.Range(xmin, xmax), Random.Range(ymin, ymax), 2.2f);
        Instantiate(shooted, instantiatepos, shooted.transform.rotation);
        aud.PlayOneShot(shootSE);
    }

    // Start is called before the first frame update
    void Start()
    {
        specialGauge_Value = 0;
        specialGauge_Max = 100;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //�X�y�V�����Q�[�W�̕\��
        SpecialGauge.value = specialGauge_Value / specialGauge_Max;
        if (specialGauge_Value >= specialGauge_Max)
        {
            Shoot();
            specialGauge_Value = 0;
            //�X�y�V�����Q�[�W�����܂邽�сA���̃X�y�V�����A�C�e�����o��܂ł̕K�v�l���傫���Ȃ�
            specialGauge_Max *= gain_Ratio;
        }
    }
}
