using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UI_ScorePopup : MonoBehaviour
{
    //�S�~�l�����̊l���X�R�A�̃|�b�v�A�b�v

    private TextMeshProUGUI popup_TMP;
    [SerializeField] private float popupSpeed;
    private float timer;
    // Start is called before the first frame update
    void Start()
    {
        popup_TMP = GetComponent<TextMeshProUGUI>();
        timer = 0;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        timer += Time.deltaTime;
        popup_TMP.rectTransform.anchoredPosition += Vector2.up * popupSpeed * timer; //�e�L�X�g�̏㏸
        popup_TMP.CrossFadeAlpha(0, 0.6f, false); //�e�L�X�g�̃t�F�[�h
        if (timer > 0.7f) Destroy(gameObject); //�e�L�X�g�̏���
    }
}
