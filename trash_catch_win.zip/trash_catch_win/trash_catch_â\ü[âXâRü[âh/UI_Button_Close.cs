using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_Button_Close : MonoBehaviour
{
    //�|�[�Y��ʂ̏I���{�^��
    [SerializeField] GameD_Pause gdp;

    // Update is called once per frame
    void Update()
    {
        if (GetComponent<UI_MyButton>().pressed)
        {
            gdp.timerStop = false;
            GetComponent<UI_MyButton>().pressed = false;
        }
    }
}
