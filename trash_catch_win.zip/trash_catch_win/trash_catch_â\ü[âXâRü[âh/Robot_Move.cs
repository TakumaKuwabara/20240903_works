using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;
using DG.Tweening;

public class Robot_Move : MonoBehaviour
{
    [SerializeField] GameD_timer gdt;

    Rigidbody rb;
    private float angle;

    [SerializeField] float MoveSpeed;
    [SerializeField] float RotationSpeed;

    private bool battery_empty;
    [SerializeField] Collider BacuumTrigger;
    [SerializeField] GameObject Platform;
    private Vector3 platformPosition;
    

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        angle = 90;
        platformPosition = Platform.transform.position;
        transform.position = platformPosition;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!gdt.countDownOver) return;
        if (gdt.timeOver) rb.velocity = Vector3.zero;

        battery_empty = GetComponent<Robot_Battery>().Battery_empty();

        if (battery_empty && gdt.timeOver == false)
        {
            //�o�b�e���[���؂ꂽ�ہA����s�\�ɂȂ莩���Ńv���b�g�t�H�[���ɖ߂�

            BacuumTrigger.enabled = false; //�S�~����p�̃R���C�_�[���~

            Vector3 toPlatform = Vector3.Scale((platformPosition - transform.position).normalized, new Vector3(1, 0, 1)) + Vector3.up * transform.position.y;
            float dis = Vector3.Distance(platformPosition, transform.position);

            float toPlatformAngle = Vector3.Angle(transform.forward, toPlatform) * -1;

            //Debug.Log(toPlatformAngle);

            //�v���b�g�t�H�[���܂ňړ��A�����������~
            if (dis <= 0.1f) rb.velocity = Vector3.zero;
            else rb.velocity = toPlatform * MoveSpeed;
            transform.DORotate(new Vector3(0, toPlatformAngle, 0), RotationSpeed);
        }
        else
        {
            BacuumTrigger.enabled = true;

            int x_way, z_way;
            Vector3 toangle;

            //�i�s�����A��]�p�̐ݒ�
            if (Input.GetKey(KeyCode.D))
            {
                x_way = -1;
                angle = 90;
            }
            else if (Input.GetKey(KeyCode.A))
            {
                x_way = 1;
                angle = -90;
            }
            else x_way = 0;

            if (Input.GetKey(KeyCode.W))
            {
                z_way = -1;
                angle = 0;
            }
            else if (Input.GetKey(KeyCode.S))
            {
                z_way = 1;
                angle = 180;
            }
            else z_way = 0;

            //�ړ��A��]
            if(!gdt.timeOver) rb.velocity = new Vector3(x_way * MoveSpeed, rb.velocity.y, z_way * MoveSpeed);

            toangle = new Vector3(0, angle, 0);
            transform.DORotate(toangle, RotationSpeed);
        }
    }
}
