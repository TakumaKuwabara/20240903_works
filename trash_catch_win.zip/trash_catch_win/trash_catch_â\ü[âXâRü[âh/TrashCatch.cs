using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class TrashCatch : MonoBehaviour
{
    [SerializeField] private GameD_Point gdp;
    [SerializeField] private ItemGenerator_Special itg_s;

    [SerializeField] private float getScore;
    [SerializeField] private float bonusRate;
    private int score;
    [SerializeField] private float getSpecial;

    [SerializeField] private bool onSE;
    private AudioSource aud;
    [SerializeField] private  AudioClip catchSE;

    [SerializeField] private GameObject ScoreCanvas;
    [SerializeField] private GameObject GetScoreText;

    private void Start()
    {
        if(gdp == null) gdp = GameObject.Find("Gamedirector").GetComponent<GameD_Point>();
        if (ScoreCanvas == null) ScoreCanvas = GameObject.Find("UICanvas");

        if(onSE) aud = GetComponent<AudioSource>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Trash"))
        {
            score = Mathf.RoundToInt(getScore * gdp.evalBonus[gdp.bonusGauge_eval]); //�l���X�R�A�̌v�Z
            gdp.sumScore += score; //���X�R�A�̉��Z
            Destroy(other.gameObject); //�擾�����S�~�̏���

            if(onSE) aud.PlayOneShot(catchSE, 0.4f); //SE��炷

            gdp.bonusGauge_value += bonusRate; //�{�[�i�X�Q�[�W�l�̉��Z
            itg_s.specialGauge_Value += getSpecial; //�X�y�V�����Q�[�W�l�̉��Z

            //�l���X�R�A�̃|�b�v�A�b�v
            GameObject scorePopup = Instantiate(GetScoreText, ScoreCanvas.transform);
            TextMeshProUGUI scorePopup_TMP = scorePopup.GetComponent<TextMeshProUGUI>();
            scorePopup_TMP.text = "+" + score.ToString();
            scorePopup_TMP.rectTransform.anchoredPosition = new Vector2(-350, -190);
        }
    }
}
