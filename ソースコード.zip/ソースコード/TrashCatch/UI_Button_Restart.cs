using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class UI_Button_Restart : MonoBehaviour
{ 
    // Update is called once per frame
    void Update()
    {
        if (GetComponent<UI_MyButton>().pressed)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
}
