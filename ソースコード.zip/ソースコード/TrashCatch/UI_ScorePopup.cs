using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UI_ScorePopup : MonoBehaviour
{
    TextMeshProUGUI popup_TMP;
    [SerializeField] float popupSpeed;
    private float timer;
    // Start is called before the first frame update
    void Start()
    {
        popup_TMP = GetComponent<TextMeshProUGUI>();
        timer = 0;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        timer += Time.deltaTime;
        popup_TMP.rectTransform.anchoredPosition += Vector2.up * popupSpeed * timer;
        popup_TMP.CrossFadeAlpha(0, 0.6f, false);
        if (timer > 0.7f) Destroy(gameObject);
    }
}
