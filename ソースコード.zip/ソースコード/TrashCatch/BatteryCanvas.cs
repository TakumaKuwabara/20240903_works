using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BatteryCanvas : MonoBehaviour
{
    // Update is called once per frame
    void FixedUpdate()
    {
        transform.rotation = Camera.main.transform.rotation;
    }
}
