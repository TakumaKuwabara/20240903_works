using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;

public class WasteBin_Move : MonoBehaviour
{
    [SerializeField] GameD_timer gdt;
    public LayerMask layer_room;
    [SerializeField] float moveSpeed;
    [SerializeField] float xmin;
    [SerializeField] float xmax;
    [SerializeField] float zmin;
    [SerializeField] float zmax;

    // Start is called before the first frame update
    void Start()
    {
        transform.position = new Vector3(-9.2f, 0f, 0.5f);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!gdt.countDownOver) return;
        if (gdt.timeOver) return;

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if(Physics.Raycast(ray, out RaycastHit hit, 50, layer_room))
        {
            //Debug.Log(hit.point);
            //transform.position = Vector3.Scale(hit.point, new Vector3(1, 0, 1));
            Vector3 targetPosition = Vector3.Scale(hit.point, new Vector3(1, 0, 1));
            transform.position = Vector3.Lerp(transform.position, targetPosition, moveSpeed * Time.deltaTime);
        }

        Vector3 pos = transform.position;
        pos.x = Mathf.Clamp(pos.x, xmin, xmax);
        pos.z = Mathf.Clamp(pos.z, zmin, zmax);
        transform.position = pos;
    }
}
