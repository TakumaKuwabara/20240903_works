using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Start_ranking : MonoBehaviour
{
    private int[] ranking = new int[5];
    private string[] rankingText = new string[5];
    [SerializeField] TextMeshProUGUI[] UI_rankingText = new TextMeshProUGUI[5];

    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < ranking.Length; i++)
        {
            ranking[i] = PlayerPrefs.GetInt(i.ToString(), 0);
            rankingText[i] = ranking[i].ToString().PadLeft(7, '0');
            UI_rankingText[i].text = (i + 1).ToString() + ": " + rankingText[i];
            Debug.Log(i.ToString() + ":saved");
        }
    }
    
}
