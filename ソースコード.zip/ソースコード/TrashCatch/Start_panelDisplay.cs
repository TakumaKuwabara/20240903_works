using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Start_panelDisplay : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    private bool carsolEnter;
    private Image ButtonImage;
    private Color originColor;
    [SerializeField] GameObject DisplayPanel;

    void Start()
    {
        carsolEnter = false;
        ButtonImage = GetComponent<Image>();
        originColor = ButtonImage.color;
    }
    // Update is called once per frame
    void Update()
    {
        DisplayPanel.SetActive(carsolEnter);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        ButtonImage.color -= new Color(0, 0, 0, 65f / 255);
        carsolEnter = true;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        ButtonImage.color = originColor;
        carsolEnter = false;
    }
}
