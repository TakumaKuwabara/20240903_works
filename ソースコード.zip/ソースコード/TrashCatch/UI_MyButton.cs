using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class UI_MyButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] private AudioDirector aud;

    public bool pressed;
    private bool carsolEnter;
    private Image ButtonImage;
    private Color originColor;
    // Start is called before the first frame update
    void Start()
    {
        pressed = false;
        carsolEnter = false;
        ButtonImage = GetComponent<Image>();
        originColor = ButtonImage.color;
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        ButtonImage.color -= new Color(55f / 255, 55f / 255, 55f / 255, 0);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (carsolEnter)
        {
            pressed = true;
            aud.DecisionSE();
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        ButtonImage.color -= new Color(0, 0, 0, 65f / 255);
        carsolEnter = true;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        ButtonImage.color = originColor;
        carsolEnter = false;
    }
}
    
