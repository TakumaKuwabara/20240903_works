using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Start_Rotate : MonoBehaviour
{
    [SerializeField] float RotationSpeed;

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(Vector3.up * Time.deltaTime * RotationSpeed);
    }
}
