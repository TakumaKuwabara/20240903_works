using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class TrashCatch : MonoBehaviour
{
    [SerializeField] GameD_Point gdp;
    [SerializeField] ItemGenerator_Special itg_s;

    [SerializeField] float getScore;
    [SerializeField] float bonusRate;
    private int score;
    [SerializeField] float getSpecial;

    [SerializeField] private bool onSE;
    private AudioSource aud;
    [SerializeField] AudioClip catchSE;

    [SerializeField] GameObject ScoreCanvas;
    [SerializeField] GameObject GetScoreText;

    private void Start()
    {
        if(gdp == null) gdp = GameObject.Find("Gamedirector").GetComponent<GameD_Point>();
        if (ScoreCanvas == null) ScoreCanvas = GameObject.Find("UICanvas");

        if(onSE) aud = GetComponent<AudioSource>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Trash"))
        {
            score = Mathf.RoundToInt(getScore * gdp.evalBonus[gdp.bonusGauge_eval]);
            gdp.sumScore += score;
            Destroy(other.gameObject);

            if(onSE) aud.PlayOneShot(catchSE, 0.4f);

            gdp.bonusGauge_value += bonusRate;
            itg_s.specialGauge_Value += getSpecial;

            GameObject scorePopup = Instantiate(GetScoreText, ScoreCanvas.transform);
            TextMeshProUGUI scorePopup_TMP = scorePopup.GetComponent<TextMeshProUGUI>();
            scorePopup_TMP.text = "+" + score.ToString();
            scorePopup_TMP.rectTransform.anchoredPosition = new Vector2(-350, -190);
        }
    }
}
