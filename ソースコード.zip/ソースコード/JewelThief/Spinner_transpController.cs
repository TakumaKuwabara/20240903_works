using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spinner_transpController : MonoBehaviour
{
    public GameObject spinnerPrefab;
    GameObject player;
    bool hasDia;
    // Start is called before the first frame update
    void Start()
    {
        this.player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        hasDia = this.player.GetComponent<PlayerController>().HaveDia();
        if(hasDia )
        {
            //�_�C���������A���̉�
            GameObject go = Instantiate(spinnerPrefab);
            go.transform.position = transform.position;
            gameObject.SetActive(false);
        }
    }
}
