using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using UnityEngine.EventSystems;
using System;

public class StageSelectDirector : MonoBehaviour
{
    public int openStage;
    public int currentOpen;
    int clearStage;
    float clearTime;

    public Button[] stageButton;
    
    public EventSystem eventSystem;
    public GameObject Panel_StageImage;
    public GameObject Panel_StageText;
    public GameObject Panel_BestTime;
    GameObject selectedObj;
    int stageNum;

    public Sprite[] StageImage;
    // Start is called before the first frame update
    void Start()
    {
        //currentOpen = PlayerPrefs.GetInt("CurrentOpen");
        //Debug.Log(currentOpen);
        //Debug.Log(openStage);
        ////openStage = PlayerPrefs.GetInt("OpenStage");
        //if (currentOpen <= PlayerPrefs.GetInt("OpenStage"))
        //{
        //    openStage = PlayerPrefs.GetInt("OpenStage");
        //    //Debug.Log(openStage);
        //    currentOpen = openStage;
        //    PlayerPrefs.SetInt("CurrentOpen", currentOpen);
        //    PlayerPrefs.Save();
        //}
        openStage = PlayerPrefs.GetInt("OpenStage", 2);
        clearStage = PlayerPrefs.GetInt("clearStage");
        clearTime = PlayerPrefs.GetFloat("clearTime");
        //Debug.Log(clearStage);
        //Debug.Log(clearTime);

        //�X�e�[�W���
        for (int i = 0; i < stageButton.Length; i++)
        {
            if (i < openStage) stageButton[i].interactable = true;

            else stageButton[i].interactable = false;
        }

        //�x�X�g�^�C���l�̃��[�h
        for(int i = 0; i < BestTimeDirector.instance.bestTime.Length; i++)
        {
            BestTimeDirector.instance.bestTime[i] = PlayerPrefs.GetFloat("savedBestTime" + i.ToString());
        }
        //�x�X�g�^�C���̍X�V
        if (BestTimeDirector.instance.bestTime[clearStage] > clearTime || BestTimeDirector.instance.bestTime[clearStage] == 0.00f)
        {
            BestTimeDirector.instance.bestTime[clearStage] = clearTime;
            //Debug.Log("save");
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        //if (Input.GetKeyDown(KeyCode.Backspace)) SceneManager.LoadScene(0);

        //�J�[�\���I�����̉�ʕ\��
        selectedObj = eventSystem.currentSelectedGameObject.gameObject;
        Panel_StageText.GetComponent<TextMeshProUGUI>().text = selectedObj.name;
        //�X�e�[�W�ԍ�
        if (selectedObj.name == "Tutorial") stageNum = 0;
        else if (selectedObj.name == "Stage1") stageNum = 1;
        else if (selectedObj.name == "Stage2") stageNum = 2;
        else if (selectedObj.name == "Stage3") stageNum = 3;
        else if (selectedObj.name == "Stage4") stageNum = 4;
        else if (selectedObj.name == "Stage5") stageNum = 5;

        Panel_StageImage.GetComponent<Image>().sprite = StageImage[stageNum];

        if (BestTimeDirector.instance.bestTime[stageNum] == 0.00)
        {
            //�x�X�g�^�C���̋L�^���Ȃ��Ƃ��ANone��\��
            Panel_BestTime.GetComponent<TextMeshProUGUI>().text = "Best:None";
        }
        else
        {
            //�x�X�g�^�C���̕\��
            Panel_BestTime.GetComponent<TextMeshProUGUI>().text = "Best:" + BestTimeDirector.instance.bestTime[stageNum].ToString("F2");
        }

    }

    public void StageSelect(string stageName)
    {
        //�x�X�g�^�C���̋L�^
        for (int i = 0; i < BestTimeDirector.instance.bestTime.Length; i++)
        {
            PlayerPrefs.SetFloat("savedBestTime" + i.ToString(), BestTimeDirector.instance.bestTime[i]);
        }
        PlayerPrefs.Save();

        AudioDirector.instance.DecisionSE();
        //T,E,S�̓��͎��A�e�X�g�V�[���ֈȍ~�A����ȊO�͎w��̃X�e�[�W��
        if (Input.GetKey(KeyCode.T) && Input.GetKey(KeyCode.E) && Input.GetKey(KeyCode.S)) SceneManager.LoadScene("test");
        else SceneManager.LoadScene(stageName);
    }
}
