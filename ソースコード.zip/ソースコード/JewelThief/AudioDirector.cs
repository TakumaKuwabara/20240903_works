using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioDirector : MonoBehaviour
{
    public static AudioDirector instance;
    AudioSource aud;
    public AudioClip decision;

    // Start is called before the first frame update
    void Start()
    {
        
    }
    private void Awake()
    {
        //AudioDirector�̃V���O���g��
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
        aud = gameObject.GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void DecisionSE()
    {
        //���艹��炷
        aud.PlayOneShot(decision);
    }
}
