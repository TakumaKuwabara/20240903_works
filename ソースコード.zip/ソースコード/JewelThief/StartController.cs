using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //�}�E�X�N���b�N�A�G���^�[�A�X�y�[�X�ŃX�e�[�W�I����
        if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space))
        {
            //Debug.Log("aaa");
            AudioDirector.instance.DecisionSE();
            SceneManager.LoadScene("StageSelect");
        }

    }
}
