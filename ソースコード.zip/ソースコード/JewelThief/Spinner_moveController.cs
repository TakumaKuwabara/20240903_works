using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class Spinner_moveController : MonoBehaviour
{
    public GameObject start;
    public GameObject end;

    Vector3 startPos;
    Vector3 endPos;
    Vector3 nextPos;
    Vector3 move;

    GameObject GameDirector;
    bool countDownEnd;
    public float speed = 0.5f;
    // Start is called before the first frame update
    void Start()
    {
        this.startPos = start.transform.position;�@//�n�_
        this.endPos = end.transform.position;�@//�I�_�A�����Ő܂�Ԃ�

        this.GameDirector = GameObject.Find("GameDirector");
        transform.position = startPos;
        nextPos = endPos;
    }

    // Update is called once per frame
    void Update()
    {
        //�J�E���g�_�E�����I�������ړ��J�n
        countDownEnd = this.GameDirector.GetComponent<GameDirector>().CountDownEnd();
        if(countDownEnd == true)
        {
            //if ((endPos - transform.position).sqrMagnitude > Mathf.Epsilon)
            //{
            //    move = Vector3.MoveTowards(transform.position, endPos, speed * Time.deltaTime);
            //}
            //else if ((startPos - transform.position).sqrMagnitude > Mathf.Epsilon)
            //{
            //    move = Vector3.MoveTowards(transform.position, startPos, speed * Time.deltaTime);
            //}

            //transform.position = move;

            //�܂�Ԃ��n�_�̍X�V
            if (transform.position == startPos) nextPos = endPos;
            if (transform.position == endPos) nextPos = startPos;
            
            //�ړ�
            transform.position = Vector3.MoveTowards(transform.position, nextPos, speed * Time.deltaTime);
        }
    }
}
