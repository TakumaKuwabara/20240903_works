using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutrialDirector : MonoBehaviour
{
    GameObject player;

    public GameObject tutorialText1;
    public GameObject tutorialText2;
    public GameObject tutorialText3;
    public GameObject tutorialText4;

    bool hasDia;

    // Start is called before the first frame update
    void Start()
    {
        this.player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        hasDia = this.player.GetComponent<PlayerController>().HaveDia();

        if (hasDia) 
        { 
            //�_�C�������O��Ńe�L�X�g�{�b�N�X�̕ύX
            tutorialText1.SetActive(false);
            tutorialText2.SetActive(false);
            tutorialText3.SetActive(true);
            tutorialText4.SetActive(true);
        }
    }
}
