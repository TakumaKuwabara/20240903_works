using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Selected : MonoBehaviour
{
    public EventSystem eventSystem;
    public GameObject Panel_StageImage;
    public GameObject Panel_StageText;

    //public Sprite StageImage;
    //public int StageNumber;
    GameObject selectedObj;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        selectedObj = eventSystem.currentSelectedGameObject;
        Panel_StageText.GetComponent<TextMeshProUGUI>().text = selectedObj.name;
        //Panel_StageImage.GetComponent<Image>().sprite = selectedObj.GetComponentInChildren<Image>.StageImage;
    }
}
